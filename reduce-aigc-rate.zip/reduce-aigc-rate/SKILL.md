---
name: reduce-aigc-rate
description: Use when the user asks to reduce AIGC rate, lower AI detection score, or rewrite a paper to sound more human-written. Triggers on keywords like "降低aigc", "降低AI率", "去AI痕迹", "论文降重", "改写论文", or when a .docx file needs AI-text camouflage.
---

# Reduce AIGC Rate

## Overview

Extract chapters from a Word document, rewrite each chapter with rules that reduce AI-detection signals, then write the modified text back to the original document. The original file is backed up before modification.

## Prerequisites

The workflow depends on Python 3.8+ with `python-docx`. Before starting, install the dependency:

```bash
pip install python-docx 2>/dev/null || pip3 install python-docx 2>/dev/null
```

If Python is not installed, guide the user per platform: Windows → https://python.org; Mac → `brew install python3`; Linux → `apt install python3-pip`.

### Find a working Python

Windows Store ships a non-functional `python3` stub, so detection must verify the interpreter actually runs:

```bash
PY=""
for cmd in python3 python py; do
  if command -v "$cmd" >/dev/null 2>&1 && "$cmd" --version >/dev/null 2>&1; then
    PY="$cmd"
    break
  fi
done
# Fallback: check common install paths on Windows
if [ -z "$PY" ] && [ -f "D:/Python3.9/python.exe" ]; then PY="D:/Python3.9/python.exe"; fi
if [ -z "$PY" ] && [ -f "C:/Python313/python.exe" ]; then PY="C:/Python313/python.exe"; fi
```

If `$PY` is still empty, tell the user Python is required and exit. Show the user how to install it.

### Verify python-docx

```bash
$PY -c "import docx" 2>/dev/null || { echo "Installing python-docx..."; $PY -m pip install python-docx; }
```

### Script paths

All scripts are in the `scripts/` directory alongside this SKILL.md. When the skill is loaded, the system prints the skill's base directory — use that path to construct script paths like `<skill-base>/scripts/extract_chapters.py`.

## Workflow

```
User provides .docx path → Extract chapters → Rewrite each chapter → Write back → Report
```

### Step 1: Create a temp directory

```bash
mkdir -p /tmp/aigc_rewrite
```

### Step 2: Extract chapters

```bash
$PY "<skill-base>/scripts/extract_chapters.py" "<docx_path>" "/tmp/aigc_rewrite"
```

This produces:
- `chapter_NN_title.txt` — one per chapter
- `_chapter_mapping.json` — chapter index, headings, paragraph counts

Read the script's stdout to know how many chapters were found. If zero chapters were extracted (no Heading styles found), treat the entire document as one chapter and copy all text to a single txt file manually.

### Step 3: Rewrite each chapter

For every `chapter_*.txt` file in `/tmp/aigc_rewrite/`:

1. Read the file
2. Rewrite the content using the rules in the next section
3. Write the modified text back to the **same file path**, overwriting the original

**CRITICAL**: Write ONLY the rewritten text. No markdown headers, no "Here's the revised version", no explanations. The file content goes directly back into the Word document.

**Large file strategy**: If a chapter is very long (more than ~2000 Chinese characters), split it into two halves at a natural paragraph boundary, rewrite each half separately, then rejoin. This ensures thorough rewriting without context-window pressure.

### Step 4: Write back to Word

```bash
$PY "<skill-base>/scripts/write_back.py" "<original_docx>" "/tmp/aigc_rewrite" "<original_docx>"
```

Using the same path for input and output overwrites the original. The script creates `<original>_backup.docx` before any changes.

If the user wants output to a different file, change the third argument.

### Step 5: Clean up and report

```bash
rm -rf /tmp/aigc_rewrite
```

Tell the user: how many chapters processed, original word count vs modified word count per chapter, backup file location.

## Rewriting Rules

核心目标：文本读起来像是一个文笔普通、写起来有些吃力的学生写的，而不是 AI 生成的流畅文本。保留专业感，但文笔平实普通。

### 结构层面

1. **调整语序**：打乱句子原有结构，灵活调换状语、定语位置。把原因放前面或后面、把修饰语换位。在中文习惯允许的范围内变换主谓宾结构，但不改变原文核心表意。

2. **交替使用把字句和被字句**：将原文的主动句随机换成把字句或被字句，反之亦然。让句式不单调。

3. **补充主语**：原文中无主语的句子，补上适当的主语。使用平实的主语如：本文/该研究/研究人员/笔者。

4. **长短句交替**：将过长的句子（超过约 30 字）拆成短句，用逗号、分号来衔接相关的分句。减少句号的使用，让段落内部衔接更松散自然。

### 词汇层面

5. **替换高频词**：识别原文中出现频率较高的词汇，用同义词或近义表达替换，避免重复用词。尤其是 AI 写作中高频出现但人类写作较少重复使用的词。

6. **避免 AI 常用过渡词**：
   - 总而言之/综上所述 → 总的来说 / 所以
   - 此外/另外 → 还有
   - 然而 → 不过 / 但
   - 因此/因而 → 所以
   - 与此同时 → 同时

7. **简化表达**：在保持专业感的前提下，让语言更加简洁直接。避免堆砌修饰词，去掉不必要的程度副词堆叠。

### 风格层面

8. **删除主观表述**：去掉「我觉得」「我认为」「笔者以为」等主观表达，改为平实的陈述句。

9. **弱化绝对语气**：
   - 必须/必然 → 需要/应该/往往会
   - 显然/显而易见 → 可以看出
   - 毋庸置疑 → 可以确定的是

10. **保留专业术语**：领域特定的专业术语、算法名称、化合物名称、医学术语等保持原样，不做替换。

### 硬性约束

- 改写后总字数变化控制在原文 ±5% 以内
- 不新增任何观点、数据或分析——只做结构调整和同义改写
- 所有引用、参考文献编号、数字、专有名词原样保留
- 段落数量保持不变，原文几个段落，改写后还是几个段落
- 核心表意不变，只改变表达方式

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| 输出文件里加 markdown 标题 | 只输出纯文本，无任何格式标记 |
| 段落数量变了 | 保持输入输出段落数量严格一致 |
| 改得太口语化 | 保留学术论文的专业感，只是文笔普通，不是口语化 |
| 替换了专业术语 | 只替换日常高频词和 AI 高频词，不碰领域专业术语 |
| 输出里加了引导语或解释 | 只输出改写后的纯内容，不加任何额外文字 |
| 句号用太多 | 多用逗号、分号衔接分句，减少句号数量 |

## 免责声明

本技能仅供学术诚信范围内的合法用途使用，包括但不限于：个人学习笔记的语言润色、原创论文的表达优化、以及合法合规的文本改写需求。用户应确保所处理的文档内容不侵犯他人知识产权，且改写行为符合所在机构或出版方的学术规范。使用者需自行承担因不当使用本技能而产生的一切责任。**禁止将本技能用于抄袭、剽窃、学术造假或其他任何违反学术道德或法律法规的用途。**
