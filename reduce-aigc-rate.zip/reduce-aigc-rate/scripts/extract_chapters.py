"""
Extract chapters from a Word document based on heading styles.
Saves each chapter as a .txt file and creates a chapter mapping JSON.
"""
import sys
import os
import json
from docx import Document


def extract_chapters(docx_path, output_dir):
    doc = Document(docx_path)
    os.makedirs(output_dir, exist_ok=True)

    chapters = []
    current_chapter = None
    chapter_idx = 0

    for para in doc.paragraphs:
        style_name = para.style.name if para.style else ''

        if style_name.startswith('Heading'):
            if current_chapter is not None and current_chapter['paragraphs']:
                chapters.append(current_chapter)

            chapter_idx += 1
            heading_level = 1
            parts = style_name.split()
            if len(parts) > 1 and parts[-1].isdigit():
                heading_level = int(parts[-1])

            title = para.text.strip()
            safe_title = "".join(
                c for c in title if c.isalnum() or c in ' _一-鿿'
            )[:50].strip()

            filename = f"chapter_{chapter_idx:02d}_{safe_title}.txt" if safe_title else f"chapter_{chapter_idx:02d}.txt"

            current_chapter = {
                'index': chapter_idx,
                'heading_level': heading_level,
                'title': title,
                'filename': filename,
                'paragraphs': []
            }
        elif current_chapter is not None:
            text = para.text.strip()
            if text:
                current_chapter['paragraphs'].append(text)

    if current_chapter is not None and current_chapter['paragraphs']:
        chapters.append(current_chapter)

    # No headings found: treat entire document as one chapter
    if not chapters:
        all_paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        if all_paras:
            chapters.append({
                'index': 1,
                'heading_level': 1,
                'title': '全文',
                'filename': 'chapter_01_全文.txt',
                'paragraphs': all_paras
            })

    mapping = []
    for ch in chapters:
        filepath = os.path.join(output_dir, ch['filename'])
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(ch['paragraphs']))

        mapping.append({
            'index': ch['index'],
            'heading_level': ch['heading_level'],
            'title': ch['title'],
            'filename': ch['filename'],
            'paragraph_count': len(ch['paragraphs'])
        })

    mapping_path = os.path.join(output_dir, '_chapter_mapping.json')
    with open(mapping_path, 'w', encoding='utf-8') as f:
        json.dump(mapping, f, ensure_ascii=False, indent=2)

    print(f"Extracted {len(chapters)} chapters to {output_dir}")
    for ch in chapters:
        print(f"  Ch{ch['index']} [H{ch['heading_level']}]: {ch['title'][:60]} "
              f"({len(ch['paragraphs'])} paragraphs) -> {ch['filename']}")


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python extract_chapters.py <docx_path> <output_dir>")
        sys.exit(1)
    extract_chapters(sys.argv[1], sys.argv[2])
