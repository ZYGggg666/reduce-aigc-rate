"""
Write modified text back to a Word document, replacing chapter content
while preserving headings, formatting, and non-paragraph elements.
FIXED: fall back to direct paragraph replacement when no Heading styles exist.
"""
import sys
import os
import json
import shutil
import copy
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def write_back(original_path, modified_dir, output_path):
    backup_path = os.path.splitext(original_path)[0] + '_backup.docx'
    if not os.path.exists(backup_path):
        shutil.copy2(original_path, backup_path)
        print(f"Backup saved to {backup_path}")

    doc = Document(original_path)
    mapping_path = os.path.join(modified_dir, '_chapter_mapping.json')

    if not os.path.exists(mapping_path):
        print("ERROR: _chapter_mapping.json not found in modified directory")
        sys.exit(1)

    with open(mapping_path, 'r', encoding='utf-8') as f:
        mapping = json.load(f)

    # Build ordered list of modified texts (index matches document heading order)
    modified_texts = []
    for ch in sorted(mapping, key=lambda x: x['index']):
        filepath = os.path.join(modified_dir, ch['filename'])
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                modified_texts.append(f.read())
        else:
            modified_texts.append('')

    body = doc.element.body

    # --- Step 1: collect all paragraph elements with their python-docx heading info ---
    para_elements = list(body.iterchildren(qn('w:p')))

    # Build a set of heading paragraph xml elements using python-docx style API
    heading_elements = set()
    for p in doc.paragraphs:
        if p.style and p.style.name and p.style.name.startswith('Heading'):
            heading_elements.add(p._element)

    has_headings = len(heading_elements) > 0
    total_text_paras = len([p for p in doc.paragraphs if p.text.strip()])

    # --- No headings: fall back to direct paragraph replacement ---
    if not has_headings:
        _replace_all_paragraphs(doc, modified_texts, output_path)
        return

    # --- Step 2: iterate through XML children and group by chapter ---
    chapter_idx = -1
    chapter_elements = []

    for child in list(body):
        tag = child.tag
        if tag == qn('w:p'):
            is_heading = child in heading_elements
            if is_heading:
                if chapter_idx >= 0 and chapter_idx < len(modified_texts) and modified_texts[chapter_idx]:
                    _replace_content(chapter_elements, modified_texts[chapter_idx])
                chapter_idx += 1
                chapter_elements = [(child, 'heading')]
            else:
                if chapter_idx >= 0:
                    chapter_elements.append((child, 'content'))
        elif tag == qn('w:tbl'):
            if chapter_idx >= 0:
                chapter_elements.append((child, 'other'))

    # Handle last chapter
    if chapter_idx >= 0 and chapter_idx < len(modified_texts) and modified_texts[chapter_idx]:
        _replace_content(chapter_elements, modified_texts[chapter_idx])

    doc.save(output_path)
    print(f"Saved modified document to {output_path}")


def _replace_all_paragraphs(doc, modified_texts, output_path):
    """Fallback when no Heading styles exist: directly replace paragraph text."""
    # Flatten all modified texts into a single list of paragraphs
    all_modified_paras = []
    for mt in modified_texts:
        all_modified_paras.extend([p.strip() for p in mt.split('\n\n') if p.strip()])

    # Get doc paragraphs that have text content
    doc_paras = [p for p in doc.paragraphs if p.text.strip()]

    for i, p in enumerate(doc_paras):
        if i < len(all_modified_paras):
            p.clear()
            p.add_run(all_modified_paras[i])

    doc.save(output_path)
    print(f"Saved modified document to {output_path} (fallback: {len(doc_paras)} paragraphs replaced)")


def _get_paragraph_text(para_elem):
    texts = []
    for t_elem in para_elem.iter(qn('w:t')):
        if t_elem.text:
            texts.append(t_elem.text)
    return ''.join(texts)


def _clear_runs(para_elem):
    for r in list(para_elem.findall(qn('w:r'))):
        para_elem.remove(r)


def _get_first_run_props(para_elem):
    runs = para_elem.findall(qn('w:r'))
    if runs:
        rPr = runs[0].find(qn('w:rPr'))
        if rPr is not None:
            return copy.deepcopy(rPr)
    return None


def _make_new_run(text, rPr=None):
    new_r = OxmlElement('w:r')
    if rPr is not None:
        new_r.insert(0, copy.deepcopy(rPr))
    t_elem = OxmlElement('w:t')
    t_elem.text = text
    t_elem.set(qn('xml:space'), 'preserve')
    new_r.append(t_elem)
    return new_r


def _clone_paragraph(para_elem):
    new_p = copy.deepcopy(para_elem)
    _clear_runs(new_p)
    return new_p


def _replace_content(elements, modified_text):
    heading_elem = None
    content_elems = []
    other_last = None

    for elem, etype in elements:
        if etype == 'heading':
            heading_elem = elem
        elif etype == 'content':
            content_elems.append(elem)
        else:
            other_last = elem

    if heading_elem is None:
        return

    new_paragraphs = [p.strip() for p in modified_text.split('\n\n') if p.strip()]
    if not new_paragraphs:
        return

    # Remove old content paragraphs
    for elem in content_elems:
        parent = elem.getparent()
        if parent is not None:
            parent.remove(elem)

    # Determine insertion point
    template_elem = content_elems[0] if content_elems else None
    insert_after = other_last if other_last is not None else heading_elem

    for para_text in new_paragraphs:
        if template_elem is not None:
            new_p = _clone_paragraph(template_elem)
        else:
            new_p = OxmlElement('w:p')

        rPr = _get_first_run_props(template_elem) if template_elem is not None else None
        new_run = _make_new_run(para_text, rPr)
        new_p.append(new_run)

        insert_after.addnext(new_p)
        insert_after = new_p


if __name__ == '__main__':
    if len(sys.argv) < 4:
        print("Usage: python write_back.py <original_docx> <modified_dir> <output_docx>")
        sys.exit(1)
    write_back(sys.argv[1], sys.argv[2], sys.argv[3])
